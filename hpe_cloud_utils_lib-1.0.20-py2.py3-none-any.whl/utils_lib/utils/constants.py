from builtins import map
from builtins import object
DEVICE_MODE_MANAGED = 0
DEVICE_MODE_MONITOR = 1
DEVICE_MODE_MANAGED_KEEP_DC = 2
DEVICE_MODE_MANAGED_DONT_KEEP_DC = 3
DEVICE_TYPE_SWITCH = '3'
DEVICE_TYPE_SWITCH_STR = 'MAS'
DEVICE_TYPE_IAP = '2'

SITE_HEALTH_FEATURE = "branchhealth"
SDWAN_FEATURE = "sdwan"
C2C_MRT_SUPPORT = "controller_on_cloud_mrt_support"


#Mobility Controller
DEVICE_TYPE_CONTROLLER = 1
DEVICE_TYPE_CONTROLLER_STR = 'MC'
#We add 100 to session_type to indicate it as KAFKA vs RMQ sesson
DEVICE_ON_KAFKA = 100
DEVICE_TYPE_CONTROLLER_KAFKA = DEVICE_ON_KAFKA + DEVICE_TYPE_CONTROLLER

MAX_SWITCH_CONFIG_RETRIES = 5
MAX_SWITCH_CONFIG_TOGGLE = 3
RETRY_FAILURE_EMAIL_TO = 'dl-athena-dev-bangalore@arubanetworks.com'
SWARM_DOWN_WAIT_TIME=300


SUPERSET_VERSION = 'superset'
SWITCH_GROUP_VERSION = SUPERSET_VERSION                     # FIXME TESTME
SWITCH_SUPPORTED_VERSIONS = ['7.3.2.0', '7.4.0.0', '7.4.0.3']
SWITCH_MAX_VERSION = SWITCH_SUPPORTED_VERSIONS[-1]
SWITCH_REBOOT_SUPPORTED_FROM = '7.3.2.2'

PATTERN_NAMESERVER = r'^(?!0|127|128|224|255)(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$'
PATTERN_NETMASK = r'^(254|252|248|240|224|192|128)\.0\.0\.0|255\.(254|252|248|240|224|192|128|0)\.0\.0|255\.255\.(254|252|248|240|224|192|128|0)\.0|255\.255\.255\.(254|252|248|240|224|192|128|0)'
PATTERN_IP = r'^(?!0|127|224|255)(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$'
PATTERN_ALLOWED_VLAN = r'^(([1-9]|\d\d|\d\d\d|[123]\d\d?\d?|40[0-8]\d|409[0-4])(-([1-9]|\d\d|\d\d\d|[123]\d\d?\d?|40[0-8]\d|409[0-4]))?)(,(([1-9]|\d\d|\d\d\d|[123]\d\d?\d?|40[0-8]\d|409[0-4])(-([1-9]|\d\d|\d\d\d|[123]\d\d?\d?|40[0-8]\d|409[0-4]))?))*$'
PATTERN_VLAN = r'^([1-9]|\d\d|\d\d\d|[123]\d\d?\d?|40[0-8]\d|409[0-4])$'
PATTERN_ADMIN_PASSWD = r'^((?!\s|\?).)*$'
PATTERN_ENABLE_PASSWD = r'^((?!\s|\?|@).)*$'

LABEL_DEFAULT_CATEGORY_ID = 1
LABEL_STORE_CATEGORY_ID = 2
LABEL_SPACE_TAG = LABEL_STORE_CATEGORY_ID
LABEL_LOCATION_TAG = 3
LABEL_ASSOCIATION_CHANGE_TOPIC = 'monitor.label_association.change'
LABEL_LIFECYCLE_CHANGE_TOPIC = 'monitor.label_lifecycle.change'
LABEL_ASSOCIATION_KEEP_ALIVE_TOPIC = 'monitor.label_association.keep_alive'

NOTIFICATION_SETTINGS_CHANGE_TOPIC = "notification_settings_changed"


class AthenaLabelErrorCode(object):
    #GenericError in label mgmt
    LABEL_ERR_DEFAULT = 'LABEL_ERR_DEFAULT'

    #Create/Update common Errors
    LABEL_ERR_NAME_TOO_LENGTHY = 'LABEL_ERR_NAME_TOO_LENGTHY'
    LABEL_ERR_INVALID_CATEGORY = 'LABEL_ERR_INVALID_CATEGORY'
    LABEL_ERR_NO_SUCH_LABEL_ID = 'LABEL_ERR_NO_SUCH_LABELID_PRESENT'
    LABEL_ERR_DUPLICATE_LABEL_NAME = 'LABEL_ERR_DUPLICATE_LABEL_NAME'
    LABEL_ERR_EMPTY_LABEL_NAME = 'LABEL_ERR_EMPTY_LABEL_NAME'

    #Bulk Label Creation Errors
    LABEL_ERR_MAX_BULK_CREATE_REQUESTS_EXCEEDED = 'LABEL_ERR_MAX_BULK_CREATE_REQUESTS_EXCEEDED'

    #CreateErrors
    LABEL_ERR_MAX_NO_ALREADY_CREATED = 'LABEL_ERR_MAX_LABELS_ALREADY_CREATED'
    LABEL_ERR_MAX_NO_ALREADY_ASSIGNED = 'LABEL_ERR_MAX_LABELS_ALREADY_ASSIGNED'
    LABEL_ERR_ALREADY_ASSOCIATED = 'LABEL_ERR_LABEL_ID_ALREADY_ASSOCIATED'
    LABEL_ASSOC_ERR_DEVICE_NOT_PRESENT = 'LABEL_ASSOC_ERR_DEVICE_NOT_PRESENT'

    #DeleteErrors
    LABEL_ERR_CHILD_LABEL_ATTACHED = 'LABEL_ERR_HAS_CHILD_LABELS_ATTACHED'
    LABEL_ERR_DELETE_ASSOCIATION = 'LABEL_ERR_UNABLE_TO_DELETE_ASSOCIATION'

    #PermissionErrors
    LABEL_ERR_CURRENT_USER_NOT_AUTHORIZED = 'LABEL_ERR_CURRENT_USER_NOT_AUTHORIZED'
    LABEL_ERR_CURRENT_USER_NO_ALL_GROUP_ACCESS = 'LABEL_ERR_CURRENT_USER_HAS_NO_ALL_GROUP_ACCESS'


class AthenaSiteErrorCode(object) :
    # GenericError in sites mgmt
    SITE_ERR_DEFAULT = 'SITE_ERR_DEFAULT'

    # Label related errors
    SITE_ERR_GET_LABELS_FAILURE = 'SITE_ERR_GET_LABELS_FAILURE'

    # Create/Update common Errors
    SITE_ERR_DUPLICATE_SITE_NAME = 'SITE_ERR_DUPLICATE_SITE_NAME'
    SITE_ERR_NO_SUCH_SITE_EXISTS = 'SITE_ERR_NO_SUCH_SITE_EXISTS'
    SITE_ERR_EMPTY_SITE_NAME = 'SITE_ERR_EMPTY_SITE_NAME'
    SITE_ERR_EMPTY_SITE_ADDRESS = 'SITE_ERR_EMPTY_SITE_ADDRESS'
    SITE_ERR_EMPTY_CITY = 'SITE_ERR_EMPTY_CITY'
    SITE_ERR_EMPTY_STATE = 'SITE_ERR_EMPTY_STATE'
    SITE_ERR_EMPTY_COUNTRY = 'SITE_ERR_EMPTY_COUNTRY'
    SITE_ERR_ADDRESS_TOO_LENGTHY = 'SITE_ERR_ADDRESS_TOO_LENGTHY__MAX_LENGTH_255'
    SITE_ERR_CITY_NAME_TOO_LENGTHY = 'SITE_ERR_CITY_NAME_TOO_LENGTHY__MAX_LENGTH_50'
    SITE_ERR_STATE_NAME_TOO_LENGTHY = 'SITE_ERR_STATE_NAME_TOO_LENGTHY__MAX_LENGTH_50'
    SITE_ERR_COUNTRY_NAME_TOO_LENGTHY = 'SITE_ERR_COUNTRY_NAME_TOO_LENGTHY__MAX_LENGTH_50'
    SITE_ERR_ZIPCODE_TOO_LENGTHY = 'SITE_ERR_ZIPCODE_TOO_LENGTHY__MAX_LENGTH_15'

    # PermissionErrors
    SITE_ERR_CURRENT_USER_NOT_AUTHORIZED = 'SITE_ERR_CURRENT_USER_NOT_AUTHORIZED'

    # Csv file error
    SITE_ERR_CSV_MORE_ROWS_THAN_MAX_ALLOWED = 'SITE_ERR_CSV_MORE_ROWS_THAN_MAX_ALLOWED'
    SITE_ERR_CSV_MORE_COLUMNS_THAN_MAX_ALLOWED = 'SITE_ERR_CSV_MORE_COLUMNS_THAN_MAX_ALLOWED'
    SITE_ERR_CSV_NO_DATA_ROWS = 'SITE_ERR_CSV_NO_DATA_ROWS'
    SITE_ERR_CSV_PROCESS_ERROR = 'SITE_ERR_CSV_PROCESS_ERROR'
    SITE_ERR_CSV_READ_ERROR = 'SITE_ERR_CSV_READ_ERROR'

    # Bulk Processing error
    SITE_ERR_REDIS_ERROR = 'SITE_ERR_REDIS_ERROR'
    SITE_ERR_NO_SUCH_TRACKING_ID = 'SITE_ERR_NO_SUCH_TRACKING_ID'


time_zones_dict = {
    'Abu-Dhabi': 'Asia/Dubai',
    'Adelaide': 'Australia/Adelaide',
    'Alaska': 'US/Alaska',
    'Amman': 'Asia/Amman',
    'Amsterdam': 'Europe/Amsterdam',
    'Arizona': 'US/Arizona',
    'Astana': 'Asia/Almaty',
    'Asuncion': 'America/Asuncion',
    'Athens': 'Europe/Athens',
    'Atlantic-Time(Canada)': 'America/Regina',
    'Auckland': 'Pacific/Auckland',
    'Azores': 'Atlantic/Azores',
    'Baghdad': 'Asia/Baghdad',
    'Baja-California': 'America/Tijuana',
    'Baku': 'Asia/Baku',
    'Bangkok': 'Asia/Bangkok',
    'Beijing': 'Asia/Shanghai',
    'Beirut': 'Asia/Beirut',
    'Belgrade': 'Europe/Belgrade',
    'Berlin': 'Europe/Berlin',
    'Bern': 'Europe/Zurich',
    'Bogota': 'America/Bogota',
    'Brasilia': 'America/Sao_Paulo',
    'Bratislava': 'Europe/Bratislava',
    'Brisbane': 'Australia/Brisbane',
    'Brussels': 'Europe/Brussels',
    'Bucharest': 'Europe/Bucharest',
    'Budapest': 'Europe/Budapest',
    'Buenos-Aires': 'America/Argentina/Buenos_Aires',
    'Cairo': 'Africa/Cairo',
    'Canberra': 'Australia/Canberra',
    'Cape-Verde-Is': 'Atlantic/Cape_Verde',
    'Caracas': 'America/Caracas',
    'Casablanca': 'Africa/Casablanca',
    'Cayenne': 'America/Cayenne',
    'Central-America': 'America/Guatemala',
    'Central-Time': 'America/Chicago',
    'Chennai': 'Asia/Kolkata',
    'Chihuahua': 'America/Chihuahua',
    'Chongqing': 'Asia/Chongqing',
    # 'Coordinated-Universal-Time': '',
    # 'Coordinated-Universal-Time+12': '',
    # 'Coordinated-Universal-Time-02': '',
    # 'Coordinated-Universal-Time-11': '',
    'Copenhagen': 'Europe/Copenhagen',
    'Cuiaba': 'America/Cuiaba',
    'Damascus': 'Asia/Damascus',
    'Darwin': 'Australia/Darwin',
    # 'Default': '',
    'Dhaka': 'Asia/Dhaka',
    'Dublin': 'Europe/Dublin',
    'East-Europe': 'Asia/Nicosia',
    # 'Eastern-Time': '',
    'Edinburgh': 'Europe/London',
    'Ekaterinburg': 'Asia/Yekaterinburg',
    'Fiji': 'Pacific/Fiji',
    'Fortaleza': 'America/Fortaleza',
    'Georgetown': 'America/Guyana',
    'Greenland': 'America/Godthab',
    'Guadalajara': 'America/Mexico_City',
    'Guam': 'Pacific/Guam',
    'Hanoi': 'Asia/Saigon',
    'Harare': 'Africa/Harare',
    'Hawaii': 'US/Hawaii',
    'Helsinki': 'Europe/Helsinki',
    'Hobart': 'Australia/Hobart',
    'HongKong': 'Hongkong',
    'Indiana(East)': 'America/Sao_Paulo',
    # 'International-Date-Line-West': '',
    'Irkutsk': 'Asia/Irkutsk',
    'Islamabad': 'Asia/Karachi',
    'Istanbul': 'Europe/Istanbul',
    'Jakarta': 'Asia/Jakarta',
    'Jerusalem': 'Asia/Jerusalem',
    'Kabul': 'Asia/Kabul',
    'Karachi': 'Asia/Karachi',
    'Kathmandu': 'Asia/Kathmandu',
    'Kolkata': 'Asia/Kolkata',
    'Krasnoyarsk': 'Asia/Krasnoyarsk',
    'Kuala-Lumpur': 'Asia/Kuala_Lumpur',
    'Kuwait': 'Asia/Kuwait',
    'Kyiv': 'Europe/Kiev',
    'La-Paz': 'America/La_Paz',
    'Lima': 'America/Lima',
    'Lisbon': 'Europe/Lisbon',
    'Ljubljana': 'Europe/Ljubljana',
    'London': 'Europe/London',
    'Madrid': 'Europe/Madrid',
    'Magadan': 'Asia/Magadan',
    'Manaus': 'America/Manaus',
    'Mazatlan': 'America/Mazatlan',
    'Melbourne': 'Australia/Melbourne',
    'Mexico-City': 'America/Mexico_City',
    'Mid-Atlantic': 'America/Halifax',
    'Minsk': 'Europe/Minsk',
    'Monrovia': 'Africa/Monrovia',
    'Monterrey': 'America/Monterrey',
    'Montevideo': 'America/Montevideo',
    'Moscow': 'Europe/Moscow',
    'Mountain-Time': 'America/Denver',
    'Mumbai': 'Asia/Kolkata',
    'Muscat': 'Asia/Muscat',
    'Nairobi': 'Africa/Nairobi',
    'New-Caledonia': 'America/Chicago',
    'New-Delhi': 'Asia/Kolkata',
    'Newfoundland': 'Canada/Newfoundland',
    'Novosibirsk': 'Asia/Novosibirsk',
    'Nukualofa': 'Pacific/Tongatapu',
    'Osaka': 'Asia/Tokyo',
    'Pacific-Time': 'US/Pacific',
    'Paris': 'Europe/Paris',
    'Perth': 'Australia/Perth',
    'Port-Louis': 'Indian/Mauritius',
    'Port-Moresby': 'Pacific/Port_Moresby',
    'Prague': 'Europe/Prague',
    'Pretoria': 'Africa/Johannesburg',
    'Quito': 'America/Guayaquil',
    'Reykjavik': 'Atlantic/Reykjavik',
    'Riga': 'Europe/Riga',
    'Riyadh': 'Asia/Riyadh',
    'Rome': 'Europe/Rome',
    'Salvador': 'America/El_Salvador',
    'Samoa': 'US/Samoa',
    'San-Juan': 'America/Argentina/San_Juan',
    'Santiago': 'America/Santiago',
    'Sapporo': 'Asia/Tokyo',
    'Sarajevo': 'Europe/Sarajevo',
    'Saskatchewan': 'Canada/Saskatchewan',
    'Seoul': 'Asia/Seoul',
    'Singapore': 'Singapore',
    'Skopje': 'Europe/Skopje',
    'Sofia': 'Europe/Sofia',
    'Solomon-Is.': 'Pacific/Guadalcanal',
    'Sri-Jayawardenepura': 'Asia/Colombo',
    'St.Petersburg': 'America/Indiana/Petersburg',
    'Stockholm': 'Europe/Stockholm',
    'Sydney': 'Australia/Sydney',
    'Taipei': 'Asia/Taipei',
    'Tallinn': 'Europe/Tallinn',
    'Tashkent': 'Asia/Tashkent',
    'Tbilisi': 'Asia/Tbilisi',
    'Tehran': 'Asia/Tehran',
    'Tokyo': 'Asia/Tokyo',
    'Ulaanbaatar': 'Asia/Ulaanbaatar',
    'Urumqi': 'Asia/Urumqi',
    'Vienna': 'Europe/Vienna',
    'Vilnius': 'Europe/Vilnius',
    'Vladivostok': 'Asia/Vladivostok',
    'Volgograd': 'Europe/Volgograd',
    'Warsaw': 'Europe/Warsaw',
    'Wellington': 'Pacific/Auckland',
    'West-Central-Africa': 'Africa/Lagos',
    'Windhoek': 'Africa/Windhoek',
    'Yakutsk': 'Asia/Yakutsk',
    'Yangon': 'Asia/Rangoon',
    'Yerevan': 'Asia/Yerevan',
    'Zagreb': 'Europe/Zagreb'
}

