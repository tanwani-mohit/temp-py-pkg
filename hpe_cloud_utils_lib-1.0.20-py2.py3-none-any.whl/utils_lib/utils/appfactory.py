# -*- coding: utf-8 -*-
"""
    Application base factory module
    ~~~~~~~~~~~~~~~~
    Use Create_app function to create the application class and initialize
    the common methods.
"""
from time import time
from builtins import str
from builtins import object
import os
import json
import datetime
from flask import Flask, request, jsonify, session
from flask_login import current_user
from flask_wtf.csrf import generate_csrf
try:
    from flask_wtf.csrf import CsrfProtect
except:
    from flask_wtf.csrf import CSRFProtect as CsrfProtect
from flask_babel import Babel
from six import ensure_str

from auth_lib.auth.constants import AuthServerConstants
from flask_kvsession import KVSessionExtension, KVSessionInterface
from simplekv.memory.redisstore import RedisStore
from simplekv.decorator import PrefixDecorator

from zeus.utils.flaskutils import json_wrap_errors
from redis_lib.kvstore.kv_layer import KVCache

from utils_lib.utils.errorhandler import webapp_unhandled_error
from utils_lib.utils.web import is_xhr
from temp_utils_lib.utils.util import get_language_for_user
from utils_lib.conf.settings import Config
from jupiter.logger import logging

log = logging.getLogger(__name__)

KVSessionInterface.serialization_method = json

csrf_protect = CsrfProtect()

class SessionManagementRedisStore(RedisStore):
    """
    This is a wrapper class on top of RedisStore, and will override put and delete functions for RedisStore.
    The purpose is to maintain session mappings between username and sessions. natively it is not supported by flask session.
    and as we are using flask_kvsession, it is not possible to get session_id. So to get session_id we need to use this class.
    """
    SESSION_TRACKING_KEY = "session-mapping-u-{username}-s-{session_id}"
    ADMIN_SESSION_TRACKING_KEY = "admin-session-mapping-u-{username}-s-{session_id}"
    
    def __init__(self, redis):
        self.redis = redis
        
    def put(self, key, data, ttl=None):
        try:
            # Session tracking code.
            session_data = json.loads(data)
            session_key = key.split(".")
            print(session_data , "------ session_data")
            print(session_key , "-------session_key--------")
            if len(session_key) > 1 and session_data.get("user_id"):
                session_id = session_key[1]
                if not check_duplicate_session_id(username=session_data['user_id'],session_id=session_id):
                    delete_sessions_for_user(username=session_data['user_id'],session_id="")
                    super(SessionManagementRedisStore, self).put(
                        self.ADMIN_SESSION_TRACKING_KEY.format(username=session_data['user_id'], session_id=session_id), data, ttl
                    )
                    super(SessionManagementRedisStore, self).put(
                        self.SESSION_TRACKING_KEY.format(username=session_data['user_id'], session_id=session_id), data, ttl
                    )
                # if "AdminSession" in session_key[0]:
                #     if not check_duplicate_session_id(username=session_data['user_id'],session_id=session_id):
                #         delete_all_admin_sessions_for_user(session_data['user_id'])
                #     super(SessionManagementRedisStore, self).put(
                #         self.ADMIN_SESSION_TRACKING_KEY.format(username=session_data['user_id'], session_id=session_id), data, ttl
                #     )
                # else:
                #     if not check_duplicate_session_id(username=session_data['user_id'],session_id=session_id):
                #         delete_all_normal_sessions_for_user(session_data['user_id'])
                #     super(SessionManagementRedisStore, self).put(
                #         self.SESSION_TRACKING_KEY.format(username=session_data['user_id'], session_id=session_id), data, ttl
                #     )
            return super(SessionManagementRedisStore, self).put(key, data)
        except Exception as e:
            log.error("Error while adding session-mapping, Exception:{}".format(e))
            return super(SessionManagementRedisStore, self).put(key, data)
    
    def delete(self, key):
        try:
            if 'global-session' in key or 'AdminSession' in key:
                session_key = key.split(".")
                if len(session_key) > 1:
                    session_id = session_key[1]
                    # Get corresponding session mapping and clear it.
                    for mapping_key in self.redis.scan_iter("*session-mapping*{}".format(session_id)):
                        super(SessionManagementRedisStore, self).delete(mapping_key)
            return super(SessionManagementRedisStore, self).delete(key)
        except Exception as e:
            log.error("Error while clearing session-mapping, Exception:{}".format(e))
            return super(SessionManagementRedisStore, self).delete(key)

def delete_all_active_sessions_for_user(username):
    """
    This function will delete all sessions for the given username.

    Args:
        username: Email id for user.
    """
    try:
        redis_conn = KVCache().get_connection(strictredis=True)
        if not redis_conn:
            raise Exception('Redis connection failure!')
        for session_mapping in redis_conn.scan_iter("*"+SessionManagementRedisStore.SESSION_TRACKING_KEY.format(username=username, session_id='')+'*'):
            session_id = session_mapping.split('-s-')[1]
            actual_session = "global-session.{}".format(session_id)
            if 'admin-session' in session_mapping:
                actual_session = "AdminSession.{}".format(session_id)
            redis_conn.delete(actual_session)
            redis_conn.delete(session_mapping)
    except Exception as e:
        log.error("Error while clearing all active session for user:{} Excpetion:{}".format(username, e))

def check_duplicate_session_id(username,session_id):
    try:
        redis_conn = KVCache().get_connection(strictredis=True)
        if not redis_conn:
            raise Exception('Redis connection failure!')
        for session_mapping in redis_conn.scan_iter("*"+SessionManagementRedisStore.SESSION_TRACKING_KEY.format(username=username, session_id=session_id)+'*'):
            print(session_mapping , "------ session_mapping ------check_duplicate_session_id------")
            if session_mapping:
                return True
    except Exception as e:
        log.error("Error while clearing all normal session for user:{} Exception:{}".format(username, e))
    return False
    
def delete_all_normal_sessions_for_user(username):
    """
    There are two type of sessions:
    - admin session (ex: AdminSession.{random-id})
    - normal session (ex: global-session.{random-id})
    This function will remove all normal sessions.

    Args:
        username: Email id for user.
    """
    try:
        redis_conn = KVCache().get_connection(strictredis=True)
        if not redis_conn:
            raise Exception('Redis connection failure!')
        for session_mapping in redis_conn.scan_iter("*"+SessionManagementRedisStore.SESSION_TRACKING_KEY.format(username=username, session_id='')+'*'):
            session_id = session_mapping.split('-s-')[1]
            actual_session = "global-session.{}".format(session_id)
            if 'admin-session' in session_mapping:
                continue
            redis_conn.delete(actual_session)
            redis_conn.delete(session_mapping)
    except Exception as e:
        log.error("Error while clearing all normal session for user:{} Exception:{}".format(username, e))
        
def delete_sessions_for_user(username, session_id=""):
    """
    There are two type of sessions:
    - admin session (ex: AdminSession.{random-id})
    - normal session (ex: global-session.{random-id})
    This function will remove all sessions.

    Args:
        username: Email id for user.
    """
    try:
        redis_conn = KVCache().get_connection(strictredis=True)
        if not redis_conn:
            raise Exception('Redis connection failure!')
        for session_mapping in redis_conn.scan_iter("*"+SessionManagementRedisStore.SESSION_TRACKING_KEY.format(username=username, session_id=session_id)+'*'):
            print(session_mapping , "------ session_mapping ------delete_all_normal_sessions_for_user")
            session_id = session_mapping.split('-s-')[1]
            actual_session = "AdminSession.{}".format(session_id) if "admin" in session_mapping else "global-session.{}".format(session_id)
            print(actual_session , "----actual_session----actual_session-----")
            redis_conn.delete(actual_session)
            redis_conn.delete(session_mapping)
    except Exception as e:
        log.error("Error while clearing all normal session for user:{} Exception:{}".format(username, e))
    
def delete_all_admin_sessions_for_user(username):
    """
    There are two type of sessions:
    - admin session (ex: AdminSession.{random-id})
    - normal session (ex: global-session.{random-id})
    This function will remove all admin sessions.

    Args:
        username: Email id for user.
    """
    try:
        redis_conn = KVCache().get_connection(strictredis=True)
        if not redis_conn:
            raise Exception('Redis connection failure!')
        for session_mapping in redis_conn.scan_iter("*"+SessionManagementRedisStore.SESSION_TRACKING_KEY.format(username=username, session_id='')+'*'):
            session_id = session_mapping.split('-s-')[1]
            actual_session = None
            if 'admin-session' in session_mapping:
                actual_session = "AdminSession.{}".format(session_id)
            else:
                continue
            redis_conn.delete(actual_session)
            redis_conn.delete(session_mapping)
    except Exception as e:
        log.error("Error while clearing all admin sessions for user:{} Exception:{}".format(username, e))
    
class AppRequestHandlers(object):
    LOG_USER_INFO = 1
    REJECT_NON_XHR_CHANGES = 2
    EXTEND_SESSION_IF_NEEDED = 4
    ADD_CSRF_TOKEN_IF_NEEDED = 8
    CLEANUP_SESSION_FLASHES = 16


disable_csrf = False
if Config.environment == "dev" and os.environ.get('ATHENA_CSRF_DISABLE'):
    # If the environemnt is dev, and there is a environment variable
    # ATHENA_CSRF_DISABLE set Disable CSRF Checks
    disable_csrf = True


def log_user_info():
    if current_user.is_authenticated:
        log.debug("Request to %s by user: [%s] <%s>",
                  request.path, str(current_user.cid), current_user.name)
    else:
        log.debug("Unauthenticated request to %s from %s",
                  request.path, request.remote_addr)


def extend_session_if_needed():
    if 'idle_timeout' in session:
        # Extending idle timeout for the session as user is active
        app = Flask(__name__)
        app.permanent_session_lifetime = datetime.timedelta(milliseconds=session['idle_timeout'])
        session.modified = True


def reject_non_xhr_changes():
    if disable_csrf:
        # If the environemnt is dev, and CSRF protection is disabled,
        # Don't check if the check is an XHR change
        return

    if (current_user.is_authenticated and request.method in ['POST', 'PUT', 'DELETE']):
        # If the request is not GET, It should be XHR
        if not is_xhr(request):
            log.debug("Rejecting non XHR change")
            return jsonify(message="Bad Request"), 400


def add_csrf_token_if_needed(response):
    if current_user.is_authenticated:
        if ((request.method == 'GET' and
                (request.path == '/admin/' or request.path.lower() == '/admin/mspview' or
                 request.path == '/frontend/' or request.path.lower() == '/frontend/mspview' or
                 request.path == '/platform/frontend/')) or
                (request.method in ['POST', 'PUT', 'DELETE'])):
            # On the first authenticated GET request. So, we set a XSRF
            # Token as a cookie or on the subsequent POST, PUT, DELETE requests
            # We refresh our XSRF Token cookie here.
            response.set_cookie('csrftoken', value=generate_csrf(), secure=True)
    return response


def cleanup_session_flashes(response):
    # remove secure content caching on browser to prevent sensitive content recovery from
    # browser storage
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate, private'
    response.headers['Pragma'] = 'no-cache'
    return response


class HTTPMethodOverrideMiddleware(object):
    '''
        HTTP Override class methods,
        See http://flask.pocoo.org/docs/0.10/patterns/methodoverrides/
        Some HTTP proxies do not support arbitrary HTTP methods or newer HTTP
        methods (such as PATCH). In that case it’s possible to “proxy” HTTP
        methods through another HTTP method in total violation of the protocol.
    '''
    allowed_methods = frozenset([
        'GET',
        'HEAD',
        'POST',
        'DELETE',
        'PUT',
        'PATCH',
        'OPTIONS'
    ])
    bodyless_methods = frozenset(['GET', 'HEAD', 'OPTIONS', 'DELETE'])

    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        method = environ.get('HTTP_X_HTTP_METHOD_OVERRIDE', '').upper()
        if method in self.allowed_methods:
            method = method.encode('ascii', 'replace')
            environ['REQUEST_METHOD'] = method
        if method in self.bodyless_methods:
            environ['CONTENT_LENGTH'] = '0'
        return self.app(environ, start_response)


def load_runtime_cfg(app):
    '''
    Read runtime cfg from file system
    '''
    pass


def validate_user_session():
    uri = request.path
    uri = ensure_str(uri.encode('ascii', 'ignore'))
    if "logout" not in uri and session.get("expiry") and session.get("expiry") < time() :
        return jsonify(errorcode="SESSION_EXPIRED", status="failure", status_code=403), 403


def _set_app_settings(app, settings_override, store_prefix,
                      app_request_handlers=0xffff,
                      wtf_csrf_enabled=True, error_handler=None):

    app.config.update(SEND_FILE_MAX_AGE_DEFAULT=0)
    app.config.update(SESSION_COOKIE_SECURE=True)
    app.config.update(REMEMBER_COOKIE_HTTPONLY=True)
    app.config.update(SESSION_COOKIE_HTTPONLY=True)
    app.config.update(PERMANENT_SESSION_LIFETIME=datetime.timedelta(days=1))

    app.config.from_object(settings_override)
    # load_runtime_cfg(app)

    json_wrap_errors(app)
    if error_handler:
        app.errorhandler(Exception)(error_handler)
    else:
        app.errorhandler(Exception)(webapp_unhandled_error)

    app.wsgi_app = HTTPMethodOverrideMiddleware(app.wsgi_app)

    # Register Before and After Request handlers
    if Config.enable_gts:
        app.before_request(validate_user_session)
    if app_request_handlers & AppRequestHandlers.LOG_USER_INFO:
        app.before_request(log_user_info)
    if app_request_handlers & AppRequestHandlers.REJECT_NON_XHR_CHANGES:
        app.before_request(reject_non_xhr_changes)
    if app_request_handlers & AppRequestHandlers.EXTEND_SESSION_IF_NEEDED:
        app.before_request(extend_session_if_needed)
    if app_request_handlers & AppRequestHandlers.ADD_CSRF_TOKEN_IF_NEEDED:
        app.after_request(add_csrf_token_if_needed)
    if app_request_handlers & AppRequestHandlers.CLEANUP_SESSION_FLASHES:
        app.after_request(cleanup_session_flashes)

    # this will replace the app's session handling
    app.secret_key = Config.secret_key

    # Use only StrictRedis for KV Store, as it expects setex in a different format
    redis_conn = KVCache().get_connection(strictredis=True)
    if not redis_conn:
        raise Exception('Redis connection failure!')
    kv_store = None
    # If AuthServer is LocalDB.
    if Config.get_auth_server == AuthServerConstants.LOCALDB:
        kv_store = SessionManagementRedisStore(redis_conn)
    else:
        kv_store = RedisStore(redis_conn)
    if os.getenv('ACP_PLATFORM') == 'platform':
        KVSessionExtension(PrefixDecorator('{}.'.format('global-session'), kv_store), app)
        app.config.update(SESSION_COOKIE_NAME='global-session')
    else:
        KVSessionExtension(PrefixDecorator('{}.'.format(store_prefix), kv_store), app)

    if not wtf_csrf_enabled or Config.environment == "dev" and os.environ.get('ATHENA_CSRF_DISABLE'):
        # If the environemnt is dev, and there is a environment variable
        # ATHENA_CSRF_DISABLE set
        # Disable CSRF Checks
        app.config.update(WTF_CSRF_ENABLED=False)

    app.config.update(WTF_CSRF_TIME_LIMIT=None)
    csrf_protect.init_app(app)


def _create_babel_app(flask_app, app_name):
    flask_app.config.update(BABEL_TRANSLATION_DIRECTORIES='language')
    flask_app.config.update(BABEL_DOMAIN=app_name)
    babel = Babel(flask_app)

    @babel.localeselector
    def get_locale():
        return get_language_for_user()


def create_app(package_name, settings_override=None,
               template_folder=None, static_folder=None,
               static_url_path=None, app_request_handlers=0xffff,
               wtf_csrf_enabled=True, error_handler=None, app_name=None,
               store_prefix='AdminSession'):
    """Returns a :class:`Flask` application instance configured with common
    functionality.

    :param package_name: application package name
    :param settings_override: a dictionary of settings to override
    """
    app = Flask(package_name, instance_relative_config=True,
                template_folder=template_folder,
                static_folder=static_folder,
                static_url_path=static_url_path)

    if app_name:
        _create_babel_app(app, app_name)

    _set_app_settings(app, settings_override,
                      app_request_handlers=app_request_handlers,
                      wtf_csrf_enabled=wtf_csrf_enabled,
                      error_handler=error_handler,
                      store_prefix=store_prefix)

    return app


def update_app(app, settings_override=None, app_request_handlers=0xffff,
               wtf_csrf_enabled=True, error_handler=None,
               store_prefix='AdminSession'):
    _set_app_settings(app, settings_override,
                      app_request_handlers=app_request_handlers,
                      wtf_csrf_enabled=wtf_csrf_enabled,
                      error_handler=error_handler,
                      store_prefix=store_prefix)
