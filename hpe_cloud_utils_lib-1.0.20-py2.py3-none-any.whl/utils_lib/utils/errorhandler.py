from flask import request, jsonify, send_from_directory

from utils_lib.utils.errors import (
    AthenaError, PermissionError, NotFoundError, BadRequestError,
    CustomerMaintenanceEx
)

from utils_lib.conf.settings import Config
from utils_lib.utils.web import is_xhr
from jupiter import apm
from jupiter.logger import logging
log = logging.getLogger(__name__)


def webapp_unhandled_error(exception):
    '''
    This is one catch exception log error for all exceptions handled
    This logs
        1. Exception Class
        2. Request Method (GET, POST, PUT, DELETE)
        3. Request Path (Helps to find which API was invoked)
        4. XHR status (Whether request is Ajax request or regular)
        5. Arguments (its a dict with 2 keys q and p.
            - q holds a dict of query arguments
            - p holds a dict of form arguments. This is empty for GET requests.

    When a PermissionError is encountered, we send a 403 to FrontEnd
    For all known AthenaErrors, we send a 409
    For all unexpected exceptions, we send a true 500
    '''
    if isinstance(exception, CustomerMaintenanceEx):
        log.info('Customer account is under maintenance')
        return jsonify(str(exception)), 500

    log.exception(
        "[%s] %s to %s - XHR: %s, Args: %s", exception.__class__.__name__,
        request.method, request.path, is_xhr(request),
        {"q": request.args.to_dict(), "p": request.form.to_dict()}
    )

    error_message = str(exception)
    error_extra = {}
    if hasattr(exception, 'extra'):
        error_extra = exception.extra

    if isinstance(exception, BadRequestError):
        return jsonify(message=error_message, extra=error_extra), 400
    elif isinstance(exception, PermissionError):
        return jsonify(message=error_message, extra=error_extra), 403
    elif isinstance(exception, NotFoundError):
        return jsonify(message=error_message, extra=error_extra), 404
    elif isinstance(exception, AthenaError):
        return jsonify(message=error_message, extra=error_extra), 409
    else:
        apm.report_exception(exception, params=error_extra)
        if Config.environment != "dev":
            # Show generic error message on non-dev environments only for non 4XX
            # Showing exact exception message would leak unnecessary information
            error_message = "An error has occurred while processing the request"

        if is_xhr(request):
            return jsonify(message=error_message, extra={}), 500
        else:
            # Not an XHR request, we will show Error page instead of JSON for this
            return send_from_directory(Config.static_path, 'common/templates/base/Error.html'), 500
