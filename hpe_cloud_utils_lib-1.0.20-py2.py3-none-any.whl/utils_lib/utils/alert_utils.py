from builtins import str
import socket
import json
import re

from jupiter.logger import logging
log = logging.getLogger(__name__)

# Creates an alert in the Sensu monitoring system
# Parameters:
#    name: name of the event, cannot contain space or special characters
#    output: detailed description of the event
def create_alert(name, output):
    if not re.match('^[a-zA-Z0-9_\-]*$', name):
        raise ValueError("name cannot contain space or special characters")

    event = {
        "name"   : name,
        "output" : output,
        "status" : 2
    }
    try:
        # Currently, every app node/container runs the sensu client
        # that's why just connecting to localhost
        clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        clientsocket.connect(('localhost', 3030))
        clientsocket.send(json.dumps(event))
        clientsocket.close()
    except Exception as e:
        log.error("Error creating alert for %s: %s", name, str(e))


if __name__ == "__main__":
    create_alert("test-alert", "test output")
