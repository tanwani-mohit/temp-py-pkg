from builtins import object
from acp_global_master_lib.clients.master_client import MasterClient
from utils_lib.conf.settings import CommonlibConf
from .response_generator import ResponseGenerator
from redis_lib.kvstore.kv_layer import KVCache
from jupiter.logger import logging as jupiter_logging


class AthenaBaseObject(object):
    config = CommonlibConf()
    cache = KVCache()
    response_generator = ResponseGenerator()
    master_client = MasterClient()
    log = jupiter_logging.getLogger(__name__)
