from builtins import object
import json

# Starting version 3.0.0, google added __version__ attribute
# Use this to load python 2 compiled protobuf.
from google import protobuf
if hasattr(protobuf, "__version__"):
    from external_imports_lib.external_imports.protobuf import hp_switch_pb2
else:
    from external_imports_lib.external_imports.protobuf2 import hp_switch_pb2

from rmq_lib.clients.mbus.switch_msg_util import (send_message_to_device,
                                                    get_athena_session_id_by_serial)
from temp_utils_lib.constants.bridge_constants import Topics
from rmq_lib.clients.mbus import AthenaPubSub
from temp_utils_lib.utils.util import get_hp_switch_rest_version
from kafka_lib.utils.kafka_utils import (publish_message_via_kafka,
                                         SWITCH_DOWNSTREAM_KAFKA_TOPIC,
                                         SWITCH_CONFIG_DOWNSTREAM_KAFKA_TOPIC)
from utils_lib.conf.settings import Config
from jupiter.logger import logging

log = logging.getLogger(__name__)


class RestActionProcessor(object):
    def __init__(self, pubsub=None):
        if pubsub is None:
            self.pubsub = AthenaPubSub(Config.rabbitmq_url, region='local')
        else:
            self.pubsub = pubsub

    def _add_rest_api_req(self, method, url, req_data, rest_api_req=None):
        if rest_api_req is None:
            rest_api_req = hp_switch_pb2.Rest_Api_Req()
        rest_api_req.method = method
        rest_api_req.url = url
        rest_api_req.req_data = req_data
        return rest_api_req

    def send_rest_command(self, device_id, session_id, topic, method, uri, session,
                          rest_command_msg, data=None, version=None, cid=None):
        rest_command = rest_command_msg.conf_node.add()
        if version is None:
            rest_version = get_hp_switch_rest_version(device_id, session)
            if not rest_version:
                rest_version = "v1"
        else:
            rest_version = version
        url = '/rest/{}/{}'.format(rest_version, uri)

        if hasattr(protobuf, "__version__"):
            req_data = b'' if data is None else str(data).encode()
        else:
            req_data = '' if data is None else data

        self._add_rest_api_req(method, url, req_data, rest_command)
        publish_message_via_kafka(cid, device_id, SWITCH_DOWNSTREAM_KAFKA_TOPIC, topic,
                                  rest_command_msg, use_flush=True)
        return

    def send_rest_get_command(self, device_id, session_id, topic, uri, session, data=None, version=None, cid=None):
        rest_command_msg = hp_switch_pb2.Rest_GetDevConfig_Req_List()
        self.send_rest_command(device_id, session_id, topic, hp_switch_pb2.HTTP_GET, uri, session,
                               rest_command_msg, data, version, cid)

    def send_rest_post_command(self, device_id, session_id, topic, uri, session, data, version=None, cid=None):
        rest_command_msg = hp_switch_pb2.Rest_SetDevConfig_Req_List()
        self.send_rest_command(device_id, session_id, topic, hp_switch_pb2.HTTP_POST, uri, session,
                               rest_command_msg, data, version, cid)

    # Add more wrapper methods like PUT/DELETE as needed

    def send_rest_get_multi_command(self, device_id, session_id, topic, uris, session, version=None, cid=None):
        rest_command_msg = hp_switch_pb2.Rest_GetDevConfig_Req_List()
        if version is None:
            rest_version = get_hp_switch_rest_version(device_id, session)
            if not rest_version:
                rest_version = "v1"
        else:
            rest_version = version
        for uri in uris:
            rest_command = rest_command_msg.conf_node.add()
            url = '/rest/{}/{}'.format(rest_version, uri)
            if hasattr(protobuf, "__version__"):
                self._add_rest_api_req(hp_switch_pb2.HTTP_GET,
                                       url, b'', rest_command)
            else:
                self._add_rest_api_req(hp_switch_pb2.HTTP_GET,
                                       url, '', rest_command)
        publish_message_via_kafka(cid, device_id, SWITCH_DOWNSTREAM_KAFKA_TOPIC, topic,
                                  rest_command_msg, use_flush=True)

    def send_rest_post_multi_command(self, device_id, session_id, topic, uri, session, req_data_list, version=None, cid=None):
        rest_command_msg = hp_switch_pb2.Rest_SetDevConfig_Req_List()
        if version is None:
            rest_version = get_hp_switch_rest_version(device_id, session)
            if not rest_version:
                rest_version = "v1"
        else:
            rest_version = version
        for data in req_data_list:
            rest_command = rest_command_msg.conf_node.add()
            url = '/rest/{}/{}'.format(rest_version, uri)
            self._add_rest_api_req(hp_switch_pb2.HTTP_POST, url, data, rest_command)
        if req_data_list:
            send_message_to_device(self.pubsub, device_id, topic, rest_command_msg, session_id,
                                   customer_id=cid)

    def _add_rest_config_req(self, conf_message, rest_req):
        # FIXME
        pass

    # static method called in this class only
    def _rest_set_conf_message(self, device_id, session_id, data, cid=None):
        conf_message = hp_switch_pb2.Rest_SetDevConfig_Req_List()
        for rest_req in data:
            self._add_rest_config_req(conf_message, rest_req)
        publish_message_via_kafka(cid, device_id, SWITCH_CONFIG_DOWNSTREAM_KAFKA_TOPIC,
                                  Topics.HP_PC_REST_SETCONFIG_REQ, conf_message)

    def _rest_get_conf_message(self, device_id, session_id, session, data=None, cid=None):
        conf_message = hp_switch_pb2.Rest_GetDevConfig_Req_List()
        get_dev_conf_msg = conf_message.conf_node.add()
        url = '/rest/config'
        rest_version = get_hp_switch_rest_version(device_id, session)
        if rest_version:
            url = "/rest/{}/config".format(rest_version)
        self._add_rest_api_req(hp_switch_pb2.HTTP_GET,
                               url, '', get_dev_conf_msg)
        publish_message_via_kafka(cid, device_id, SWITCH_CONFIG_DOWNSTREAM_KAFKA_TOPIC,
                                  Topics.HP_PC_REST_GETCONFIG_REQ, conf_message)

    def _rest_set_localconf_message(self, device_id, session_id, data, cid=None):
        # FIXME update localconf_message with provided data
        localconf_message = self._add_rest_api_req(hp_switch_pb2.HTTP_POST,
                                                   '/rest/setlocalconf',
                                                   json.dumps({"set_local_conf": data}))

        publish_message_via_kafka(cid, device_id, SWITCH_CONFIG_DOWNSTREAM_KAFKA_TOPIC,
                                  Topics.HP_PC_REST_LOCALCONF_REQ, localconf_message)

        send_message_to_device(self.pubsub, device_id,
                               Topics.HP_PC_REST_LOCALCONF_REQ,
                               localconf_message, session_id, customer_id=cid)

    # Following methods are called from outside to send messages to device
    def send_rest_conf_to_device(self, device_id, session, data, cid=None):
        log.info("push config to device: conf_set_dev_config: {}".format(data))
        session_id = get_athena_session_id_by_serial(device_id, None, session)
        if session_id:
            self._rest_set_conf_message(device_id, session_id, data, cid)

    def get_rest_config_from_device(self, device_id, session, session_id=None, data=None, cid=None):
        log.info("get configuration from device: conf_get_dev_config")
        if session_id is None:
            session_id = get_athena_session_id_by_serial(device_id, None, session)
        if session_id:
            self._rest_get_conf_message(device_id, session_id, session, cid=cid)

    def set_local_config_in_device(self, device_id, session, session_id, data, cid=None):
        log.info("set local config in the device: rest_set_local_conf")
        if session_id is None:
            session_id = get_athena_session_id_by_serial(device_id, None, session)
        if session_id:
            self._rest_set_localconf_message(device_id, session_id, data, cid)

    def send_upgrade_firmware_to_device(self, device_id, session, image_url):
        # FIXME
        pass

    def send_reload_to_device(self, device_id, session):
        # FIXME
        pass

    def send_rest_config_list_to_device(self, device_id, rest_config_list, session, cid=None):
        log.info("publishing config list to device: {} conf_set_dev_config: {}".format(device_id, rest_config_list))
        publish_message_via_kafka(cid, device_id, SWITCH_CONFIG_DOWNSTREAM_KAFKA_TOPIC,
                                  Topics.HP_PC_REST_SETCONFIG_REQ, rest_config_list)
