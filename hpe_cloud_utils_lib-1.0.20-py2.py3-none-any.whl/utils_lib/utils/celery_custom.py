import multiprocessing

from celery.worker import autoscale

from jupiter.logger import logging
log = logging.getLogger(__name__)

ATHENA_AUTOSCALE_KEEPALIVE = 900


class AthenaCeleryAutoscaler(autoscale.Autoscaler):
    def __init__(self, pool, max_concurrency,
                 min_concurrency=0, worker=None,
                 keepalive=ATHENA_AUTOSCALE_KEEPALIVE, mutex=None):
        log.critical("No celery autoscaling; Capping max to 1")
        # On prod, workers should be using concurreny of 4 or less per pod
        autoscale.Autoscaler.__init__(
            self, pool, 1, 1,
            worker, keepalive, mutex
        )
