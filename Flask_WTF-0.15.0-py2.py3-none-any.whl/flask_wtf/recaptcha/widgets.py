from __future__ import absolute_import
from flask import Markup, current_app, json
from werkzeug.urls import url_encode

JSONEncoder = json.JSONEncoder

RECAPTCHA_SCRIPT = u'https://www.google.com/recaptcha/api.js'
RECAPTCHA_TEMPLATE = u'''
<script src='%s' async defer></script>
<div class="g-recaptcha" %s></div>
'''

__all__ = [u'RecaptchaWidget']


class RecaptchaWidget(object):

    def recaptcha_html(self, public_key):
        html = current_app.config.get(u'RECAPTCHA_HTML')
        if html:
            return Markup(html)
        params = current_app.config.get(u'RECAPTCHA_PARAMETERS')
        script = RECAPTCHA_SCRIPT
        if params:
            script += u'?' + url_encode(params)

        attrs = current_app.config.get(u'RECAPTCHA_DATA_ATTRS', {})
        attrs[u'sitekey'] = public_key
        snippet = u' '.join([u'data-{}="{}"'.format(k, attrs[k]) for k in attrs])
        return Markup(RECAPTCHA_TEMPLATE % (script, snippet))

    def __call__(self, field, error=None, **kwargs):
        u"""Returns the recaptcha input HTML."""

        try:
            public_key = current_app.config[u'RECAPTCHA_PUBLIC_KEY']
        except KeyError:
            raise RuntimeError(u'RECAPTCHA_PUBLIC_KEY config not set')

        return self.recaptcha_html(public_key)
