from __future__ import absolute_import
import warnings


def to_bytes(text):
    u"""Transform string to bytes."""
    if isinstance(text, unicode):
        text = text.encode(u'utf-8')
    return text


def to_unicode(input_bytes, encoding=u'utf-8'):
    u"""Decodes input_bytes to text if needed."""
    if not isinstance(input_bytes, unicode):
        input_bytes = input_bytes.decode(encoding)
    return input_bytes


class FlaskWTFDeprecationWarning(DeprecationWarning):
    pass


warnings.simplefilter(u'always', FlaskWTFDeprecationWarning)
warnings.filterwarnings(
    u'ignore', category=FlaskWTFDeprecationWarning, module=u'wtforms|flask_wtf'
)
