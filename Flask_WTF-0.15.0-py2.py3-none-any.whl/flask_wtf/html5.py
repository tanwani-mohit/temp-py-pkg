from __future__ import absolute_import
import warnings

from ._compat import FlaskWTFDeprecationWarning

warnings.warn(FlaskWTFDeprecationWarning(
    u'"flask_wtf.html5" will be removed in 1.0.  '
    u'Import directly from "wtforms.fields.html5" '
    u'and "wtforms.widgets.html5".'
), stacklevel=2)

from wtforms.widgets.html5 import *
from wtforms.fields.html5 import *
