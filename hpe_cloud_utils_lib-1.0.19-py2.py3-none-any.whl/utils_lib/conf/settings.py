from builtins import object
from auth_lib.auth.constants import AuthServerConstants, DeploymentConstants

from jupiter.logger import logging
from jupiter.conf import Config as JupiterConfig  # SettingsObject


class CommonlibConf(object):
    def __init__(self):
        self.jupiter_config = JupiterConfig
        self.jupiter_config.depends_on([
            'orders', 'spark', 'gmaster', 'api_gw', 'activate', 's3', 'apistreaming'
        ])

        self._apigw_url = None
        self._apigw_admin_url = None
        self.pubsub_logger = None

    def __getattr__(self, name):
        # if the attribute is found through the normal mechanism, __getattr__() is not called
        # if the attribute is not found normally, it gets lookedup in jupiter_config object
        # Or, it raises an AttribuetError when attribute is not there in jupiter_config too
        return getattr(self.jupiter_config, name)

    @property
    def spark_master_web_url(self):
        return self.spark.get('master_web_url', [])

    @property
    def activate_config(self):
        return self.activate

    @property
    def boomi_config(self):
        return self.boomi

    @property
    def apigw_url(self):
        if self._apigw_url:
            return self._apigw_url
        host = self.api_gw.get('host', 'localhost')
        port = self.api_gw.get('port', 443)
        protocol = self.api_gw.get('protocol', 'https')
        self._apigw_url = "{}://{}:{}".format(protocol, host, port)
        return self._apigw_url

    @property
    def apigw_admin_url(self):
        if self._apigw_admin_url:
            return self._apigw_admin_url
        host = self.api_gw.get('admin', {}).get('host', 'localhost')
        port = self.api_gw.get('admin', {}).get('port', 443)
        protocol = self.api_gw.get('admin', {}).get('protocol', 'https')

        self._apigw_admin_url = "{}://{}:{}".format(protocol, host, port)
        return self._apigw_admin_url

    @property
    def apigw_apikey(self):
        return self.api_gw.get('apikey', None)

    @property
    def apigw_verify_cert(self):
        '''
            if verify_cert is present in runtime.conf, use that
            else, determine this based on env
        '''
        verify_cert = self.api_gw.get('verify_cert', None)
        if verify_cert is not None:
            return verify_cert

        return self.environment in [self.environment_prod, self.environment_alpha]

    @property
    def apigw_admin_verify_cert(self):
        return self.apigw_verify_cert

    @property
    def apigw_auto_license(self):
        return self.api_gw.get('auto_license', False)

    @property
    def glis_config(self):
        return self.orders.get('glis', {})

    @property
    def enable_gts(self):
        return self.glis_config.get("enable_gts", False)

    @property
    def system_under_maintenance(self):
        return self.orders.get('system_under_maintenance', False)

    @property
    def kong_api_name(self):
        return self.api_gw.get('kong_api_name', None)

    @property
    def apigw_enable(self):
        return self.api_gw.get('enable', False)

    @property
    def pubsub_log_level(self):
        return self.log_level.get("pubsub", logging.WARN)

    def getPubsubLogger(self):
        if not hasattr(self, "pubsub_logger") or self.pubsub_logger is None:
            self.pubsub_logger = logging.getLogger("pubsub")
            self.pubsub_logger.setLevel(self.pubsub_log_level)
        return self.pubsub_logger

    @property
    def get_deployment_type(self):
        return self.cluster_info.get('deployment', DeploymentConstants.PUBLIC)
    
    @property
    def get_auth_server(self):
        return self.cluster_info.get('auth_server', AuthServerConstants.ARUBASSO)

    @property
    def get_PA_enabled(self):
        return self.pa.get('enabled', 'false')

    @property
    def is_apistreaming_enabled(self):
        return self.api_gw.get('streaming', {}).get('enable', False)

    @property
    def is_apistreaming_compression(self):
        return self.api_gw.get('streaming', {}).get('compression', False)

    @property
    def get_http_streaming(self):
        streaming_server = self.api_gw.get('streaming', {})
        return "{}://{}:{}".format(
            streaming_server.get('post_protocol', "http"),
            streaming_server.get('host', 'localhost'),
            streaming_server.get('httpport', 10178)
        )

    @property
    def get_streaming_subscriber(self):
        streaming_server = self.api_gw.get('streaming', {})
        return streaming_server.get('protocol', "tcp"), \
            streaming_server.get('host', 'localhost'),\
            streaming_server.get('subport', 10175)

    @property
    def udp_ipcport_map(self):
        try:
            return self.apistreaming.get('udp_ipcportmap', {})
        except Exception:
            return {}

    @property
    def get_streaming_cids(self):
        '''
        Temporary code to get the list of CID's for whom stremaing is enabled
        Currently all our private cloud custoemrs are using the beta setup
        and we do not want to stream device info to all
        '''
        return self.api_gw.get('streaming', {}).get('cids', [])

    @property
    def is_filter_streaming(self):
        '''
        Temporary code to get the list of CID's for whom stremaing is enabled
        Currently all our private cloud custoemrs are using the beta setup
        and we do not want to stream device info to all
        '''
        return self.api_gw.get('streaming', {}).get('filter_streaming', False)

    @property
    def events_mq(self):
        '''
            abstracting the message queue details
        '''
        return self.rabbitmq_url

    @property
    def get_hc_nodes(self):
        return self.hazelcast.get('nodes', [])

    # TODO: Depracate this
    @property
    def get_athena_static_data_url(self):
        return self.static.get('athena_static_data_url', 'http://athena-static.central.arubanetworks.com/')

    @property
    def disable_rmq_compression(self):
        return self.rabbitmq.get('disable_rmq_compression', False)

    @property
    def get_orders_google_api_key(self):
        return self.orders.get('orders_google_api').get('key')

    @property
    def disable_gmaster_cache(self):
        return self.gmaster.get('disable_gmaster_cache', False)

    @property
    def get_cluster_name(self):
        """
        Needed for beta whitelisting
        """
        return self.cluster_info.get('cluster_name', None)

    @property
    def get_athena_static_data(self):
        return self.s3.get('athena_static_s3', {})

    # CACW: Customer-Access-to-Cluster-Whitelist
    @property
    def get_cacw_data(self):
        return self.s3.get('cust_to_msp_s3', {})

    @property
    def get_clusteraccess_data(self):
        return self.s3.get('clusteraccess_s3', {})

    @property
    def search_cluster_version(self):
        return self.elasticsearch.get("search_cluster", {}).get("version", "2.x")

    @property
    def is_c2c_mrt_enabled_cluster(self):
        try:
            return self.static.get('c2c_mrt_enabled_cluster', False)
        except Exception:
            return False

    @property
    def is_acp_navigation_enabled(self):
        try:
            return self.orders.get('acp_navigation', False)
        except Exception:
            return False

    @property
    def is_att_deployment(self):
        return self.cluster_info.get("att_env", False)

    @property
    def mailer(self):
        return self.static.get('mailer', {})

    @property
    def notifier_attachments_aws_s3(self):
        return self.s3.get('notifier_attachments_aws_s3', {})

Config = CommonlibConf()
