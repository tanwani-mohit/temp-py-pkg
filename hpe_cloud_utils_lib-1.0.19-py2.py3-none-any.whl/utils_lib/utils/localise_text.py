from builtins import str
from builtins import object
import gettext
import os

from acp_global_signup_lib.constants.user import UserLanguages
from temp_utils_lib.utils.util import get_language_for_user
from jupiter.logger import logging as jupiter_logging


log = jupiter_logging.getLogger(__name__)


class TextLocaliser(object):
    FOLDER_TRANSLATION = '/language'

    def __init__(self, app_name, app_path=os.getcwd(), username=None, language=None):
        if username:
            language = get_language_for_user(username)
        elif not language or not UserLanguages.is_valid_language(language):
            log.info("Invalid language {}. Falling back to default {}".format(
                language, UserLanguages.DEFAULT))
            language = UserLanguages.DEFAULT

        self._localiser = gettext.translation(app_name, app_path + self.FOLDER_TRANSLATION,
                                              [language])

    def gettext(self, text):
        return str(self._localiser.gettext(text), "utf8")
