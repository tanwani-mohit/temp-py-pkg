from flask import jsonify

from constants_lib.constants.http_status_codes import HTTPStatusCodes


class ResponseGenerator(HTTPStatusCodes):
    @classmethod
    def generate(cls, status_code, error_code=None):
        flask_response = {}
        if status_code >= cls._ERROR_CODE_START_INDEX:
            flask_response[cls.KEY_ERROR_CODE] = error_code or cls._ERROR_CODES.get(status_code)

        response = jsonify(flask_response)
        response.status_code = status_code
        return response
