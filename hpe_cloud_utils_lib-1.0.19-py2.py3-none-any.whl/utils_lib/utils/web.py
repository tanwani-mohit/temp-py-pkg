from builtins import range
from html import escape

from flask import jsonify


def sanitize(data):
    """
    WARNING: for performance reasons, data will be modified in place.  if you need the value in data
    for something else, make a copy before sending it into sanitize

    iterate through structure in data and html escape all strings
    """
    if isinstance(data, dict):
        for key in list(data.keys()):
            data[key] = sanitize(data[key])
    elif isinstance(data, (list, tuple)):
        for index in range(len(data)):
            data[index] = sanitize(data[index])
    elif isinstance(data, str):
        return escape(data, True)
    else:
        return data
    return data


def json_response(raw_data, sanitized=False):
    """
    WARNING: if satitized==False, raw_data will be changed in place as needed
    if you need raw_data for something else, make a copy before passining it into
    json_response.  This is done because copy.deepcopy is incredibly expensive

    iterate through structure in raw_data and html escape all strings and return a flash Response object
    if sanitize==True, it will be assumed that the data is already safe and just convert it to a Response object
    """
    if not sanitized:
        sanitize(raw_data)
    response = jsonify(raw_data)
    return response


def is_xhr(request):
    return request.headers.get('X-Requested-with', "").lower() == "xmlhttprequest"
