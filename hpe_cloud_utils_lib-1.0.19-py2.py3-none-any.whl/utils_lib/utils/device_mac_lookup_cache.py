from builtins import str
from builtins import object
from redis_lib.kvstore.kv_layer import KVCache
from jupiter.logger import logging
log = logging.getLogger(__name__)


class DeviceMacCache(object):

    DEVICE_MAC_LOOKUP_CACHE = 'mon:DeviceMacLookupCache'  # DO NOT MODIFY
    DEVICE_MAC_LOOKUP_CACHE_AGE = 90 * 24 * 60 * 60  # 3 months

    @classmethod
    def get_by_mac(cls, macaddr):
        if macaddr is None:
            raise ValueError('mac address is None')
        macaddr = cls._canonicalize_mac(macaddr)
        key = cls._key_mac(macaddr)
        serial = cls._read(key)
        return serial

    @classmethod
    def delete(cls, macaddr):
        macaddr = cls._canonicalize_mac(macaddr)
        key = cls._key_mac(macaddr)
        try:
            redis_conn = KVCache().get_connection()
            redis_conn.delete(key)
        except Exception as e:
            log.exception('Error deleting DeviceCache for {} - {}'.format(key, e))
        return None

    @classmethod
    def invalidate_cache(cls, macaddr):
        cls.delete(macaddr)

    @classmethod
    def cache(cls, macaddr, serial):
        if macaddr is None:
            raise ValueError('mac address is None')
        macaddr = cls._canonicalize_mac(macaddr)
        key = cls._key_mac(macaddr)
        cls._store(key, serial, cls.DEVICE_MAC_LOOKUP_CACHE_AGE)

    @classmethod
    def _read(cls, key):
        try:
            redis_conn = KVCache().get_connection()
            val = redis_conn.get(key)
            return val
        except Exception as e:
            log.error('Error reading DeviceCache for {} - {}'.format(key, e))
            return None

    @classmethod
    def _store(cls, key, val, expiry=None):
        try:
            redis_conn = KVCache().get_connection()
            redis_conn.set(key, val, ex=expiry)
        except Exception as e:
            log.error('Error building DeviceCache for {} - {}'.format(val, e))
        return None

    @classmethod
    def _canonicalize_mac(cls, macaddr):
        return str(macaddr.upper())

    @classmethod
    def _key_mac(cls, macaddr):
        return '{}:{}'.format(cls.DEVICE_MAC_LOOKUP_CACHE, macaddr)
