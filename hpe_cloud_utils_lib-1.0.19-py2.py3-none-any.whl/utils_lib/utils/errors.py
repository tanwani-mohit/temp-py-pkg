# FIXME Move this out of utils


class AthenaError(Exception):
    def __init__(self, message, extra=None):
        Exception.__init__(self, message)
        self.extra = extra or {}


class ReadError(AthenaError):
    pass


class CreateError(AthenaError):
    pass


class UpdateError(AthenaError):
    pass


class DeleteError(AthenaError):
    pass


class AthenaValueError(AthenaError):
    pass


class PermissionError(AthenaError):
    pass


class ConfigError(AthenaError):
    pass


class NotFoundError(AthenaError):
    pass


class OrderParserError(AthenaError):
    pass


class BadRequestError(AthenaError):
    pass


class OrderError(AthenaError):
    pass


class PciInvalidError(AthenaError):
    pass


class LeaderboardError(AthenaError):
    pass


class CustomerMaintenanceEx(AthenaError):
    def __init__(self, message='Customer is under maintenance. '
                               'Please try after sometime', extra=None):
        super(CustomerMaintenanceEx, self).__init__(message, extra)
